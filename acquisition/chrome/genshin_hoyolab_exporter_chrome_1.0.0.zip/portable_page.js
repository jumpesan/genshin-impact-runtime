"use strict";

(() => {
  const namespace = "__genshinHoyolabPortablePage";

  async function postJson(url, payload) {
    const headers = new Headers();
    headers.set("Accept", "application/json, text/plain, */*");
    headers.set("Content-Type", "application/json");

    const response = await fetch(url, {
      method: "POST",
      credentials: "include",
      headers,
      body: JSON.stringify(payload)
    });

    const text = await response.text();
    let json = null;
    try {
      json = JSON.parse(text);
    } catch {
      // Error below includes only a short excerpt.
    }

    if (!response.ok || !json || json.retcode !== 0) {
      throw new Error(
        `HoYoLAB API failed: status=${response.status}, retcode=${json?.retcode ?? "no-retcode"}, message=${json?.message ?? "no-message"}, raw=${json ? "" : text.slice(0, 500)}`
      );
    }

    return json;
  }

  async function acquireRaw(config) {
    if (location.origin !== "https://act.hoyolab.com") {
      throw new Error(`Unexpected page origin: ${location.origin}`);
    }

    const { listUrl, detailUrl, server, roleId } = config ?? {};
    if (!listUrl || !detailUrl || !server || !roleId) {
      throw new Error("HoYoLAB acquisition config is incomplete.");
    }

    const listJson = await postJson(listUrl, {
      server,
      role_id: roleId
    });

    const characterIds = Array.isArray(listJson?.data?.list)
      ? listJson.data.list
          .map((entry) => entry?.id)
          .filter((id) => Number.isInteger(id))
      : [];

    if (characterIds.length === 0) {
      throw new Error("character/list returned no character IDs.");
    }

    const detailJson = await postJson(detailUrl, {
      server,
      role_id: roleId,
      character_ids: characterIds
    });

    const returnedCharacterIds = Array.isArray(detailJson?.data?.list)
      ? detailJson.data.list
          .map((entry) => entry?.base?.id)
          .filter((id) => Number.isInteger(id))
      : [];

    const requestedSet = new Set(characterIds);
    const returnedSet = new Set(returnedCharacterIds);
    const missingCharacterIds = characterIds.filter((id) => !returnedSet.has(id));
    const unexpectedCharacterIds = returnedCharacterIds.filter((id) => !requestedSet.has(id));

    if (
      returnedCharacterIds.length !== characterIds.length ||
      missingCharacterIds.length > 0 ||
      unexpectedCharacterIds.length > 0
    ) {
      throw new Error(
        `character/detail incomplete: requested=${characterIds.length}, returned=${returnedCharacterIds.length}, missing=${missingCharacterIds.join(",")}, unexpected=${unexpectedCharacterIds.join(",")}`
      );
    }

    return {
      format: "genshin_hoyolab_raw_snapshot",
      format_version: "0.1-poc",
      generated_at: new Date().toISOString(),
      source: {
        provider: "HoYoLAB",
        page_origin: location.origin,
        server
      },
      responses: {
        character_list: listJson,
        character_detail: detailJson
      }
    };
  }

  function downloadText(text, fileName) {
    if (typeof text !== "string" || text.length === 0) {
      throw new Error("Download text is empty.");
    }
    if (typeof fileName !== "string" || fileName.length === 0) {
      throw new Error("Download filename is empty.");
    }

    const blob = new Blob([text], { type: "application/json" });
    const objectUrl = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = objectUrl;
    anchor.download = fileName;
    anchor.style.display = "none";
    document.documentElement.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(objectUrl), 30000);

    return {
      ok: true,
      fileName,
      bytes: blob.size
    };
  }

  globalThis[namespace] = {
    acquireRaw,
    downloadText
  };
})();
