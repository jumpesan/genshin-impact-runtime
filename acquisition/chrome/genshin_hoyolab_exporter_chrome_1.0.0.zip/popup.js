"use strict";

const API_ORIGIN = "https://sg-act-public-api.hoyolab.com";
const LIST_URL = `${API_ORIGIN}/event/game_record/genshin/api/character/list`;
const DETAIL_URL = `${API_ORIGIN}/event/game_record/genshin/api/character/detail`;

const output = document.getElementById("output");
const refreshButton = document.getElementById("refresh");
const portableButton = document.getElementById("portable");

function render(value) {
  output.textContent = JSON.stringify(value, null, 2);
}

async function getCapture() {
  const response = await chrome.runtime.sendMessage({ type: "getCapture" });
  if (!response?.ok) {
    throw new Error(response?.error ?? "Failed to read HoYoLAB request context.");
  }

  const capture = response.capture;
  if (!capture?.server || !capture?.roleId) {
    throw new Error(
      "HoYoLAB request context is not captured yet. Open or reload the Genshin Battle Chronicle first."
    );
  }

  return capture;
}

async function getActiveHoYoLabTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab = tabs[0];

  if (!tab?.id) {
    throw new Error("Active HoYoLAB tab was not found.");
  }

  if (typeof tab.url === "string" && !tab.url.startsWith("https://act.hoyolab.com/")) {
    throw new Error("Open the HoYoLAB Battle Chronicle tab before exporting.");
  }

  return tab;
}

async function refreshState() {
  try {
    const response = await chrome.runtime.sendMessage({ type: "getCapture" });
    const capture = response?.capture ?? null;
    render({
      ready: Boolean(response?.ok && capture?.server && capture?.roleId),
      server: capture?.server ?? null,
      updatedAt: capture?.updatedAt ?? null
    });
  } catch (error) {
    render({ ok: false, error: String(error) });
  }
}

async function acquireRawFromActivePage() {
  const capture = await getCapture();
  const tab = await getActiveHoYoLabTab();

  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    files: ["portable_page.js"]
  });

  const acquisition = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    func: async (config) => globalThis.__genshinHoyolabPortablePage.acquireRaw(config),
    args: [
      {
        listUrl: LIST_URL,
        detailUrl: DETAIL_URL,
        server: capture.server,
        roleId: capture.roleId
      }
    ]
  });

  const raw = acquisition?.[0]?.result;
  if (!raw) {
    throw new Error("HoYoLAB acquisition returned no Raw Snapshot.");
  }

  return { tab, raw };
}

async function downloadTextInPage(tab, text, fileName) {
  const download = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    func: (downloadText, downloadFileName) =>
      globalThis.__genshinHoyolabPortablePage.downloadText(downloadText, downloadFileName),
    args: [text, fileName]
  });

  const result = download?.[0]?.result;
  if (!result?.ok) {
    throw new Error("Download did not complete.");
  }

  return result;
}

function filenameTimestamp(generatedAt) {
  return generatedAt.replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
}

function assertPortablePrivacy(text) {
  const forbidden = [
    /"role_id"\s*:/i,
    /"game_role_id"\s*:/i,
    /"cookie"\s*:/i,
    /"authorization"\s*:/i,
    /"(?:auth_token|access_token|refresh_token|token)"\s*:/i,
    /"(?:device_id|device_fp|devicefp)"\s*:/i,
    /"x[-_]rpc[^"\\]*"\s*:/i
  ];

  for (const pattern of forbidden) {
    if (pattern.test(text)) {
      throw new Error(`Portable privacy check failed: ${pattern}`);
    }
  }
}

async function exportPortableContext() {
  const { tab, raw } = await acquireRawFromActivePage();
  const portable = globalThis.normalizeHoYoLabRawSnapshot(raw);

  if (
    portable?.format !== "genshin_portable_user_context" ||
    portable?.format_version !== "0.1-draft"
  ) {
    throw new Error("Unexpected Portable User Context contract version.");
  }

  const text = JSON.stringify(portable, null, 2);
  assertPortablePrivacy(text);

  const generatedAt = portable.generated_at ?? new Date().toISOString();
  const fileName = `genshin_portable_user_context_${filenameTimestamp(generatedAt)}.json`;
  const downloadResult = await downloadTextInPage(tab, text, fileName);

  return {
    ok: true,
    fileName,
    bytes: downloadResult.bytes,
    characterCount: portable.characters.length,
    coverage: portable.coverage
  };
}

refreshButton.addEventListener("click", refreshState);

portableButton.addEventListener("click", async () => {
  portableButton.disabled = true;
  render({ exportingPortableContext: true });
  try {
    render(await exportPortableContext());
  } catch (error) {
    render({ ok: false, error: error?.message ?? String(error) });
  } finally {
    portableButton.disabled = false;
  }
});

refreshState();
