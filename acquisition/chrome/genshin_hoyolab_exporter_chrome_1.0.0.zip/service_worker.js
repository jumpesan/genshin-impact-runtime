"use strict";

const CAPTURE_KEY = "hoyolabCapture";
const OBSERVED_URLS = [
  "https://sg-act-public-api.hoyolab.com/event/game_record/genshin/api/character/list*",
  "https://sg-act-public-api.hoyolab.com/event/game_record/genshin/api/character/detail*"
];

function decodeRawBody(raw = []) {
  const chunks = raw
    .map((part) => part?.bytes)
    .filter((bytes) => bytes instanceof ArrayBuffer)
    .map((bytes) => new Uint8Array(bytes));

  if (chunks.length === 0) {
    return null;
  }

  const totalLength = chunks.reduce((sum, chunk) => sum + chunk.byteLength, 0);
  const merged = new Uint8Array(totalLength);
  let offset = 0;

  for (const chunk of chunks) {
    merged.set(chunk, offset);
    offset += chunk.byteLength;
  }

  return new TextDecoder().decode(merged);
}

function decodeRequestBody(requestBody) {
  if (!requestBody) {
    return null;
  }

  if (requestBody.formData) {
    const body = {};
    for (const [key, values] of Object.entries(requestBody.formData)) {
      body[key] = Array.isArray(values) && values.length === 1 ? values[0] : values;
    }
    return body;
  }

  try {
    const text = decodeRawBody(requestBody.raw);
    return text ? JSON.parse(text) : null;
  } catch {
    return null;
  }
}

async function storeCaptureFromRequest(requestBody) {
  const body = decodeRequestBody(requestBody);
  if (!body || typeof body.server !== "string") {
    return;
  }

  if (typeof body.role_id !== "string" && typeof body.role_id !== "number") {
    return;
  }

  await chrome.storage.session.set({
    [CAPTURE_KEY]: {
      server: body.server,
      roleId: String(body.role_id),
      updatedAt: new Date().toISOString()
    }
  });
}

chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    storeCaptureFromRequest(details.requestBody).catch(console.error);
  },
  { urls: OBSERVED_URLS },
  ["requestBody"]
);

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "getCapture") {
    return false;
  }

  chrome.storage.session
    .get(CAPTURE_KEY)
    .then((stored) => {
      const capture = stored[CAPTURE_KEY] ?? null;
      sendResponse({ ok: true, capture });
    })
    .catch((error) => sendResponse({ ok: false, error: String(error) }));

  return true;
});
