"use strict";

function invariant(condition, message) {
  if (!condition) {
    throw new Error(message);
  }
}

function isObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function normalizeVerificationProperty(property) {
  if (!isObject(property) || !Number.isInteger(property.property_type)) {
    return null;
  }

  return {
    property_type: property.property_type,
    base: property.base ?? "",
    add: property.add ?? "",
    final: property.final ?? ""
  };
}

function normalizeVerificationProperties(properties) {
  if (!Array.isArray(properties)) {
    return [];
  }

  return properties
    .map(normalizeVerificationProperty)
    .filter(Boolean);
}

function normalizeArtifactStat(property) {
  if (!isObject(property) || !Number.isInteger(property.property_type)) {
    return null;
  }

  const normalized = {
    property_type: property.property_type,
    value: property.value ?? ""
  };

  if (Number.isInteger(property.times)) {
    normalized.source_times = property.times;
  }

  return normalized;
}

function normalizeArtifact(relic) {
  invariant(isObject(relic), "artifact entry must be an object");
  invariant(Number.isInteger(relic.pos), "artifact pos is required");
  invariant(Number.isInteger(relic.id), "artifact id is required");

  const mainStat = normalizeArtifactStat(relic.main_property);
  invariant(mainStat !== null, `artifact ${relic.id} main_property is required`);

  return {
    slot: relic.pos,
    piece_id: relic.id,
    set_id: Number.isInteger(relic?.set?.id) ? relic.set.id : null,
    rarity: relic.rarity ?? null,
    level: relic.level ?? null,
    main_stat: mainStat,
    substats: Array.isArray(relic.sub_property_list)
      ? relic.sub_property_list.map(normalizeArtifactStat).filter(Boolean)
      : []
  };
}

function normalizeWeapon(weapon) {
  invariant(isObject(weapon), "equipped weapon is required");
  invariant(Number.isInteger(weapon.id), "weapon id is required");

  return {
    weapon_id: weapon.id,
    level: weapon.level ?? null,
    ascension_level: weapon.promote_level ?? null,
    refinement: weapon.affix_level ?? null
  };
}

function normalizeConstellationState(constellation) {
  invariant(isObject(constellation), "constellation entry must be an object");
  invariant(Number.isInteger(constellation.id), "constellation id is required");
  invariant(
    typeof constellation.is_actived === "boolean",
    `constellation ${constellation.id} is_actived is required`
  );
  invariant(
    typeof constellation.is_enhanced === "boolean",
    `constellation ${constellation.id} is_enhanced is required`
  );

  return {
    constellation_id: constellation.id,
    position: constellation.pos ?? null,
    active: constellation.is_actived,
    enhanced: constellation.is_enhanced
  };
}

function normalizeConstellationVerification(constellation) {
  if (!isObject(constellation) || !Number.isInteger(constellation.id)) {
    return null;
  }

  if (typeof constellation.can_enhanced !== "boolean") {
    return null;
  }

  return {
    constellation_id: constellation.id,
    can_enhanced: constellation.can_enhanced
  };
}

function normalizeSkillState(skill) {
  invariant(isObject(skill), "skill entry must be an object");
  invariant(Number.isInteger(skill.skill_id), "skill_id is required");
  invariant(
    typeof skill.is_unlock === "boolean",
    `skill ${skill.skill_id} is_unlock is required`
  );
  invariant(
    typeof skill.is_enhanced === "boolean",
    `skill ${skill.skill_id} is_enhanced is required`
  );

  return {
    skill_id: skill.skill_id,
    level: skill.level ?? null,
    unlocked: skill.is_unlock,
    enhanced: skill.is_enhanced
  };
}

function normalizeSkillVerification(skill) {
  if (!isObject(skill) || !Number.isInteger(skill.skill_id)) {
    return null;
  }

  if (typeof skill.can_enhanced !== "boolean") {
    return null;
  }

  return {
    skill_id: skill.skill_id,
    can_enhanced: skill.can_enhanced
  };
}

function normalizeCharacter(detail) {
  invariant(isObject(detail), "character detail must be an object");
  invariant(isObject(detail.base), "character detail.base is required");
  invariant(Number.isInteger(detail.base.id), "character id is required");

  const constellations = Array.isArray(detail.constellations)
    ? detail.constellations.map(normalizeConstellationState)
    : [];
  const skills = Array.isArray(detail.skills)
    ? detail.skills.map(normalizeSkillState)
    : [];

  const sourceConstellationCount = detail.base.actived_constellation_num;
  if (Number.isInteger(sourceConstellationCount)) {
    const canonicalActiveCount = constellations.filter((entry) => entry.active).length;
    invariant(
      sourceConstellationCount === canonicalActiveCount,
      `character ${detail.base.id} constellation count mismatch: source=${sourceConstellationCount}, active_nodes=${canonicalActiveCount}`
    );
  }

  const character = {
    character_id: detail.base.id,
    level: detail.base.level ?? null,
    friendship_level: detail.base.fetter ?? null,
    current_element: detail.base.element ?? null,
    constellations,
    skills,
    equipped_weapon: normalizeWeapon(detail.weapon),
    equipped_artifacts: Array.isArray(detail.relics)
      ? detail.relics.map(normalizeArtifact)
      : [],
    verification: {
      hoyolab_actived_constellation_num: Number.isInteger(sourceConstellationCount)
        ? sourceConstellationCount
        : null,
      hoyolab_constellation_can_enhanced: Array.isArray(detail.constellations)
        ? detail.constellations
            .map(normalizeConstellationVerification)
            .filter(Boolean)
        : [],
      hoyolab_skill_can_enhanced: Array.isArray(detail.skills)
        ? detail.skills
            .map(normalizeSkillVerification)
            .filter(Boolean)
        : [],
      hoyolab_selected_properties: normalizeVerificationProperties(detail.selected_properties),
      hoyolab_base_properties: normalizeVerificationProperties(detail.base_properties),
      hoyolab_extra_properties: normalizeVerificationProperties(detail.extra_properties),
      hoyolab_element_properties: normalizeVerificationProperties(detail.element_properties)
    }
  };

  character.equipped_artifacts.sort((a, b) => a.slot - b.slot);
  character.constellations.sort((a, b) => (a.position ?? 0) - (b.position ?? 0));
  character.skills.sort((a, b) => a.skill_id - b.skill_id);
  character.verification.hoyolab_constellation_can_enhanced.sort(
    (a, b) => a.constellation_id - b.constellation_id
  );
  character.verification.hoyolab_skill_can_enhanced.sort(
    (a, b) => a.skill_id - b.skill_id
  );

  return character;
}

function normalizeHoYoLabRawSnapshot(raw) {
  invariant(isObject(raw), "raw snapshot must be an object");
  invariant(raw.format === "genshin_hoyolab_raw_snapshot", "unsupported raw snapshot format");
  invariant(isObject(raw.responses), "raw.responses is required");

  const listResponse = raw.responses.character_list;
  const detailResponse = raw.responses.character_detail;

  invariant(isObject(listResponse), "character_list response is required");
  invariant(isObject(detailResponse), "character_detail response is required");
  invariant(listResponse.retcode === 0, `character_list retcode=${listResponse.retcode}`);
  invariant(detailResponse.retcode === 0, `character_detail retcode=${detailResponse.retcode}`);

  const list = listResponse?.data?.list;
  const details = detailResponse?.data?.list;

  invariant(Array.isArray(list), "character_list.data.list must be an array");
  invariant(Array.isArray(details), "character_detail.data.list must be an array");

  const listIds = list.map((entry) => entry?.id);
  const detailIds = details.map((entry) => entry?.base?.id);

  invariant(listIds.every(Number.isInteger), "character_list contains an invalid character id");
  invariant(detailIds.every(Number.isInteger), "character_detail contains an invalid character id");
  invariant(new Set(listIds).size === listIds.length, "character_list contains duplicate character ids");
  invariant(new Set(detailIds).size === detailIds.length, "character_detail contains duplicate character ids");

  const listIdSet = new Set(listIds);
  const detailIdSet = new Set(detailIds);
  const missingIds = listIds.filter((id) => !detailIdSet.has(id));
  const unexpectedIds = detailIds.filter((id) => !listIdSet.has(id));

  invariant(missingIds.length === 0, `character_detail missing ids: ${missingIds.join(",")}`);
  invariant(unexpectedIds.length === 0, `character_detail unexpected ids: ${unexpectedIds.join(",")}`);

  const detailById = new Map(details.map((detail) => [detail.base.id, detail]));
  const characters = listIds.map((id) => normalizeCharacter(detailById.get(id)));

  return {
    format: "genshin_portable_user_context",
    format_version: "0.1-draft",
    generated_at: raw.generated_at ?? null,
    source: {
      provider: "HoYoLAB",
      server: raw?.source?.server ?? null,
      raw_format: raw.format,
      raw_format_version: raw.format_version ?? null
    },
    coverage: {
      characters: "complete",
      character_details: "complete",
      equipped_weapons: "equipped_only",
      equipped_artifacts: "equipped_only",
      weapon_inventory: "unavailable",
      artifact_inventory: "unavailable",
      character_ascension: "not_explicit_in_source"
    },
    characters
  };
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    normalizeHoYoLabRawSnapshot
  };
}

if (typeof globalThis !== "undefined") {
  globalThis.normalizeHoYoLabRawSnapshot = normalizeHoYoLabRawSnapshot;
}
